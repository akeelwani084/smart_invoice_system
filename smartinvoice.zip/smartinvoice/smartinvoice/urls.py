from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.index, name='index'),
    path('product/', views.product, name='product'),
    path('upload/', views.upload_image, name='upload_image'),
    path('', views.login, name='login'),
    path('demo/', views.demo, name='demo'),
    path('signup', views.registration_view, name='registration'),
    path('logindata/', views.some_view, name='some_view'),
    path('companydata/', views.store_data, name='store_data'),
]