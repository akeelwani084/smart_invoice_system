from django.db import models

class SignUp(models.Model):
    user_id = models.CharField(max_length=100, unique=True)
    password = models.CharField(max_length=15)

class Company(models.Model):
    user = models.OneToOneField(SignUp, on_delete=models.CASCADE, primary_key=True)
    company_name = models.CharField(max_length=100)
    company_gst = models.CharField(max_length=15, unique=True)  # Assuming GSTIN is unique
    company_address = models.TextField()
    company_contact_number = models.CharField(max_length=15)
    company_gmail = models.EmailField()
    company_logo = models.ImageField(upload_to='company_logos/')

class Upload(models.Model):
    invoice = models.ImageField(upload_to='invoice/')