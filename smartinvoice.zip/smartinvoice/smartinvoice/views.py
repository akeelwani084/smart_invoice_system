from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
import pdfplumber
import pandas as pd
from .models import SignUp, Company, Upload
import re
from django.contrib.auth.decorators import login_required

def validate_mobile_number(mobile_number):
    pattern = r'^(\+91[\-\s]?)?[0]?(91)?[789]\d{9}$'
    return re.match(pattern, mobile_number)

def validate_gst_number(gst_number):
    pattern = r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$'
    return re.match(pattern, gst_number)

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email)

def registration_view(request):
    if request.method == 'POST':
        login_id = request.POST.get('login_id')
        password = request.POST.get('password')
        company_name = request.POST.get('company_name')
        company_gst = request.POST.get('company_gst')
        company_address = request.POST.get('company_address')
        company_contact_number = request.POST.get('company_contact_number')
        company_gmail = request.POST.get('company_gmail')
        company_logo = request.FILES.get('company_logo')

        if not validate_mobile_number(company_contact_number):
            error_message = "Invalid mobile number. Please enter a valid mobile number."
            return render(request, 'registration.html', {'error_message': error_message})

        if not validate_gst_number(company_gst):
            error_message = "Invalid GST number. Please enter a valid GST number."
            return render(request, 'registration.html', {'error_message': error_message})
        
        if not validate_email(company_gmail):
            error_message = "Invalid Gmail. Please enter a valid Gmail."
            return render(request, 'registration.html', {'error_message': error_message})

        # if not validate_mobile_number(company_contact_number):
        #     return HttpResponse("Invalid mobile number. Please enter a valid mobile number.")

        # if not validate_gst_number(company_gst):
        #     return HttpResponse("Invalid GST number. Please enter a valid GST number.")
        
        # def validate_email(email):
        #     pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        #     return HttpResponse("Invalid Gmail. Please enter a valid Gmail.")

        try:
            # Check if the user_id already exists
            existing_user = SignUp.objects.get(user_id=login_id)
            return HttpResponse("User ID already exists. Please choose a different one.")
        
        except SignUp.DoesNotExist:
            # Create a new user signup record
            new_user = SignUp.objects.create(user_id=login_id, password=password)

            # Create a new company record
            new_company = Company.objects.create(
                user=new_user,
                company_name=company_name,
                company_gst=company_gst,
                company_address=company_address,
                company_contact_number=company_contact_number,
                company_gmail=company_gmail,
                company_logo=company_logo
            )
            new_company.save()
            return redirect('login')
    return render(request, 'registration.html')


def upload_image(request):
    if request.method == 'POST' and request.FILES.get('image'):
        input_file = request.FILES.get('image')
        upload = Upload.objects.create(invoice=input_file)
        upload.save()

        file_extension = input_file.name.split('.')[-1]

        if file_extension.lower() in ['jpg', 'jpeg', 'png']:
            extracted_data = image_invoice_ocr(input_file)
        elif file_extension.lower() == 'pdf':
            extracted_data = pdf_invoice_ocr(input_file)
        else:
            return HttpResponse("File format not supported")
        
        # Render product.html with extracted data
        return render(request, 'product.html', {'extracted_data': extracted_data})
    else:
        return HttpResponse("No image found")

def image_invoice_ocr(request):
    pass

def pdf_invoice_ocr(input_path):
    extracted_data = {}
    with pdfplumber.open(input_path) as pdf:
        page = pdf.pages[0]
        text_data = page.extract_text()

    # Extract GSTIN
    gstin_match = re.search(r"GSTIN\s+(\w+)", text_data)
    extracted_data['GSTIN'] = gstin_match.group(1) if gstin_match else None

    # Extract company details based on GSTIN
    if extracted_data['GSTIN'] == '33AZACR4849R2ZI':
        extracted_data['Company'] = "Quantbit Technologies Pvt Ltd."
        extracted_data['Address'] = "Shriram Fortune, Vishrambag Sangli, Maharashtra India, 416415"
    elif extracted_data['GSTIN'] == "04ARCPD987431Z5":
        extracted_data['Company'] = "Kantech Solutions Pvt Ltd."
        extracted_data['Address'] = "23 & 24 AMR Tech Park Internal Rd, Hongasandra Bengaluru, Karnataka 560068"
    
    # Extract date
    date_match = re.search(r"\d{1,2}/\d{1,2}/\d{4}", text_data)
    extracted_data['Date'] = date_match.group() if date_match else None
    
    # Extract invoice number
    invoice_number_match = re.search(r"Invoice no. (\d+)", text_data)
    extracted_data['Invoice Number'] = invoice_number_match.group(1) if invoice_number_match else None


    # Extract item details
    items_data = re.findall(r"^(.*?)\s+(\d+)\s+Rs\.\s*([\d,]+)\s+Rs\.\s*([\d,]+)", text_data, re.MULTILINE)
    items = []
    for item in items_data:
        items.append({
            'Description': item[0],
            'Quantity': int(item[1]),
            'Unit_Price': int(item[2].replace(',', '')),
            'Amount': int(item[3].replace(',', ''))
        })
    extracted_data['Items'] = items

    # Extract total
    total_match = re.search(r"Total\s+Rs\.\s*([\d,]+)", text_data)
    extracted_data['Total'] = total_match.group(1).replace(',', '') if total_match else None
    
    store_data(extracted_data)
    return extracted_data

# def pdf_invoice_ocr(input_path):
#     extracted_data = {}
#     with pdfplumber.open(input_path) as pdf:
#         page = pdf.pages[0]
#         text_data = page.extract_text()

#     # Extract GSTIN
#     gst_regex = r"(?i)GSTIN ([\w\-]+)"
#     gst_matches = re.findall(gst_regex, text_data)

#     # Extract company details based on GSTIN
#     if gst_matches[1] == '27AAACO8276F1Z6':
#         extracted_data['Company'] = "Quantbit Technologies Pvt Ltd."
#         extracted_data['Address'] = "Shriram Fortune, Vishrambag Sangli, Maharashtra India, 416415"
#     elif gst_matches[0] == "29AADCK0643D1ZU":
#         extracted_data['Company'] = "Kallatra Technologies Private Limited"
#         extracted_data['Address'] = "Kallatra Technologies Private Limited, Bangalore Karnataka 560025 India"
    
#     # Extract date
#     date_match = re.search(r"(\d{1,2}/\d{1,2}/\d{4})", text_data).group()
#     extracted_data['Date'] = date_match if date_match else None
    
#     # Extract invoice number
#     invoice_number_match = re.search(r"Invoice no. (\d+)", text_data)
#     extracted_data['Invoice Number'] = invoice_number_match.group(1) if invoice_number_match else None


#     # Extract item details
#     matches = re.findall(r'(\d+) (.*?) (\d+)(?:,\d+)* (.*?) (\d+(?:,\d+)?(?:\.\d+)?)', text_data)
#     items_df = pd.DataFrame(matches, columns=['Sr', 'Description of Goods', 'HSN/SAC', 'Quantity', 'Rate per'])
#     items_df['Quantity'] = items_df['Quantity'].astype(float)
#     items_df['Rate per'] = items_df['Rate per'].str.replace(',', '').astype(float)
#     items_df['Amount'] = items_df['Quantity'] * items_df['Rate per']
#     items = []
#     for index, row in items_df.iterrows():
#         items.append({
#             'Description': row['Description of Goods'],
#             'HSN': row['HSN/SAC'],
#             'Quantity': row['Quantity'],
#             'Unit_Price': row['Rate per'],
#             'Amount': row['Amount']
#         })
#     extracted_data['Items'] = items
#     print(extracted_data)


#     subtotal = 0
#     for i in items_df['Amount']:
#         subtotal += i

#     gst_percentage = re.search(r'(\d{1,3}%)', text_data).group()
#     percentage_without_percent_sign = gst_percentage.rstrip('%')
#     gst_amount = (subtotal/100) * int(percentage_without_percent_sign)

#     total = subtotal + gst_amount

#     extracted_data['Total'] = total if total else None
    
#     store_data(extracted_data)
#     return extracted_data

@login_required
def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('index')
        else:
            return render(request, 'login.html', {'error': 'Invalid username or password'})
    else:
        return render(request, 'login.html')

@login_required
def some_view(request):
    l = []
    signups = SignUp.objects.all()
    for signup in signups:
        l.append(signup.user_id)
        l.append(',')
        l.append(signup.password)
        print("Login ID:", signup.user_id)
        print("Password:", signup.password)
    return HttpResponse(l)


@login_required
def demo(request):
    # Logic for login view
    return render(request, 'demo.html')

@login_required
def index(request):
    return render(request, 'index.html')

@login_required
def product(request):
    return render(request, 'product.html')

def store_data(request):
    l = []
    datas = Company.objects.all()
    for data in datas:
        l.append(data.company_name)
        print("User Data: ", data.company_name)
    return HttpResponse(l)